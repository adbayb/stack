# Contributing

Thanks for showing interest to contribute to `{{pkg_name}}` 🥳.
We are open to contributions, we look forward to improving it with your help!

Here you will find guidelines that will help you to know how to contribute to this repository.
It can be about reporting an issue, proposing a bug fix, adding some features, and even more...

## 🥇 Your first contribution

TODO

## 🗂️ Conventions

TODO

## 👨‍🍳 Recipes

### How to XXX?

TODO
