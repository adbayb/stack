---
"{{projectName}}": minor
---

v0.1.0 release 🚀
