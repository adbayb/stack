<br>
<div align="center">
    <h1>📦 {{pkg_name}}</h1>
    <strong>{{pkg_description}}</strong>
</div>
<br>
<br>

## ✨ Features

TODO

<br>

## 🚀 Usage

This section introduces the `{{pkg_name}}` essentials by walking through its main commands:

0️⃣ ...
1️⃣ ...
2️⃣ ...
3️⃣ ...

<br>

## 🏗️ Architecture

TODO

<br>

## ✍️ Contribution

We're open to new contributions, you can find more details [here](https://github.com/{{repo_id}}/blob/main/CONTRIBUTING.md).

<br>

## 📖 License

[MIT](https://github.com/{{repo_id}}/blob/main/LICENSE "License MIT")

<br>
