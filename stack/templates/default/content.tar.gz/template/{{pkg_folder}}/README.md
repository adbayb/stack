<br>
<div align="center">
    <h1>📦 {{pkg_name}}</h1>
    <strong>{{pkg_description}}</strong>
</div>
<br>
<br>

## ✨ Features

TODO

<br>

## 🚀 Quickstart

TODO

0️⃣ ...
1️⃣ ...
2️⃣ ...
3️⃣ ...

<br>

## 🏗️ Architecture

TODO

<br>

## ✍️ Contribution

We're open to new contributions, you can find more details [here](../CONTRIBUTING.md).

<br>

## 📖 License

[MIT](../LICENSE "License MIT")
