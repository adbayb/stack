import { describe, expect, test } from "vitest";

import { HELLO_WORLD } from ".";

describe("XXX", () => {
	test("should render correctly", () => {
		expect(HELLO_WORLD).toEqual("to be implemented");
	});
});
