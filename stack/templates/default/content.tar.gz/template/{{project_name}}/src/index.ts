export const todo = "Hello 👋, please replace me!";
