export const HELLO_WORLD = "Hello 👋, please replace me!";
