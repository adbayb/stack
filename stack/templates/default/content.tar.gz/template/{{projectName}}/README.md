<br>
<div align="center">
    <h1>📦 {{projectName}}</h1>
    <strong>{{projectDescription}}</strong>
</div>
<br>
<br>

## ✨ Features

TODO

<br>

## 🚀 Usage

This section introduces the `{{projectName}}` essentials by walking through its main commands:

0️⃣ ...
1️⃣ ...
2️⃣ ...
3️⃣ ...

<br>

## 🏗️ Architecture

TODO

<br>

## ✍️ Contribution

We're open to new contributions, you can find more details [here](https://github.com/{{repoId}}/blob/main/CONTRIBUTING.md).

<br>

## 📖 License

[MIT](https://github.com/{{repoId}}/blob/main/LICENSE "License MIT")

<br>
