import { HELLO_WORLD } from "{{project_name}}";

console.log(HELLO_WORLD);
