import { HELLO_WORLD } from "{{projectName}}";

console.log(HELLO_WORLD);
